import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 60
NODE_HEIGHT = 40
HORIZONTAL_GAP = 40
CANVAS_HEIGHT = 120
CANVAS_WIDTH = 900


# Singly Linked List Classes

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert_at_index(self, data, index):
        new_node = Node(data)

        if index == 0:
            new_node.next = self.head
            self.head = new_node
            return True

        current = self.head
        prev = None
        count = 0

        while current and count < index:
            prev = current
            current = current.next
            count += 1

        if count == index:
            prev.next = new_node
            new_node.next = current
            return True

        return False

    def delete_value(self, value):
        current = self.head
        prev = None

        while current:
            if current.data == value:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                return True
            prev = current
            current = current.next

        return False

    def search(self, value):
        current = self.head
        index = 0

        while current:
            if current.data == value:
                return index
            current = current.next
            index += 1

        return -1

    def to_list(self):
        arr = []
        current = self.head
        while current:
            arr.append(current.data)
            current = current.next
        return arr

# Visualiser

class SLLVisualizer:

    def __init__(self, root):

        self.root = root
        self.root.title("Singly Linked List Visualiser")

        self.sll = SinglyLinkedList()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="white")
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        # Insert
        tk.Label(control_frame, text="Insert Value").grid(row=0, column=0)
        self.insert_value = tk.Entry(control_frame, width=5)
        self.insert_value.grid(row=0, column=1)

        tk.Label(control_frame, text="Index").grid(row=0, column=2)
        self.insert_index = tk.Entry(control_frame, width=5)
        self.insert_index.grid(row=0, column=3)

        tk.Button(control_frame, text="Insert", command=self.insert_node).grid(row=0, column=4, padx=10)

        # Delete
        tk.Label(control_frame, text="Delete Value").grid(row=1, column=0)
        self.delete_value = tk.Entry(control_frame, width=5)
        self.delete_value.grid(row=1, column=1)

        tk.Button(control_frame, text="Delete", command=self.delete_node).grid(row=1, column=4, padx=10)

        # Search
        tk.Label(control_frame, text="Search Value").grid(row=2, column=0)
        self.search_value = tk.Entry(control_frame, width=5)
        self.search_value.grid(row=2, column=1)

        tk.Button(control_frame, text="Search", command=self.search_node).grid(row=2, column=4, padx=10)

        self.status = tk.Label(root, text="", font=("Arial", 12), fg="blue")
        self.status.pack(pady=10)

        self.draw_list()


# Drawing Functions


    def draw_node(self, x, y, data, highlight=False):

        color = "yellow" if highlight else "lightblue"

        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill=color, outline="black", width=2
        )

        self.canvas.create_text(
            x + NODE_WIDTH / 2,
            y + NODE_HEIGHT / 2,
            text=str(data),
            font=("Arial", 14)
        )

    def draw_arrow(self, x1, y1, x2, y2):
        self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST, width=2)

    def draw_list(self, highlight_index=None):

        self.canvas.delete("all")

        nodes = self.sll.to_list()

        x = 20
        y = 40

        centers = []

        for i, val in enumerate(nodes):

            highlight = (i == highlight_index)

            self.draw_node(x, y, val, highlight)

            centers.append((x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2))

            x += NODE_WIDTH + HORIZONTAL_GAP

        # draw arrows (one direction only)
        for i in range(len(centers) - 1):

            x1, y1 = centers[i]
            x2, y2 = centers[i + 1]

            self.draw_arrow(x1 + 20, y1, x2 - 20, y2)

# Button Functions

    def insert_node(self):

        try:
            value = int(self.insert_value.get())
            index = int(self.insert_index.get())
        except ValueError:
            messagebox.showerror("Error", "Enter valid integers")
            return

        success = self.sll.insert_at_index(value, index)

        if success:
            self.status.config(text=f"Inserted {value} at index {index}")
            self.draw_list()
        else:
            messagebox.showerror("Error", "Index out of range")

    def delete_node(self):

        try:
            value = int(self.delete_value.get())
        except ValueError:
            messagebox.showerror("Error", "Enter a valid integer")
            return

        success = self.sll.delete_value(value)

        if success:
            self.status.config(text=f"Deleted {value}")
            self.draw_list()
        else:
            messagebox.showinfo("Not Found", "Value not in list")

    def search_node(self):

        try:
            value = int(self.search_value.get())
        except ValueError:
            messagebox.showerror("Error", "Enter a valid integer")
            return

        index = self.sll.search(value)

        if index != -1:
            self.status.config(text=f"Value {value} found at index {index}")
            self.draw_list(highlight_index=index)
        else:
            self.status.config(text=f"Value {value} not found")
            self.draw_list()

# Run Program

if __name__ == "__main__":

    root = tk.Tk()

    app = SLLVisualizer(root)

    root.mainloop()