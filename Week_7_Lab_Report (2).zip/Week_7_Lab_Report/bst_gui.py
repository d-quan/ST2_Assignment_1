import tkinter as tk
from tkinter import messagebox
import time
import random
import string
from collections import deque


# ---------------- BST NODE ----------------

class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


# ---------------- CONTACT BST NODE ----------------

class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


# ---------------- CONTACT DIRECTORY (BST) ----------------

class ContactDirectory:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Contact(name, phone)

        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone

        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root

        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        while root.left:
            root = root.left
        return root

    def delete(self, root, name):
        if root is None:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        return root

    def inorder(self, root, result=None):
        if result is None:
            result = []

        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)

        return result


# ---------------- GUI APPLICATION ----------------

class BSTVisualizerApp:
    def __init__(self, root):
        self.directory = ContactDirectory()

        self.root = root
        self.root.title("BST Contact Directory")

        # Input frame
        frame = tk.Frame(root)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1)

        # Buttons
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=5)

        tk.Button(btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(btn_frame, text="Show All", command=self.show_all).grid(row=0, column=3, padx=5)
        tk.Button(btn_frame, text="Benchmark", command=self.benchmark).grid(row=0, column=4, padx=5)

        # Output box
        self.output = tk.Text(root, height=12, width=70)
        self.output.pack(pady=10)

        # Canvas (tree view placeholder)
        self.canvas = tk.Canvas(root, width=800, height=400, bg="white")
        self.canvas.pack()

        self.root.after(200, self.draw_tree)

    # ---------------- GUI FUNCTIONS ----------------

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Error", "Enter both name and phone")
            return

        self.directory.root = self.directory.insert(self.directory.root, name, phone)

        self.output.insert(tk.END, f"Inserted: {name}\n")
        self.clear_inputs()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()

        node = self.directory.search(self.directory.root, name)

        self.output.delete(1.0, tk.END)

        if node:
            self.output.insert(tk.END, f"FOUND:\n{name} - {node.phone}\n")
        else:
            self.output.insert(tk.END, "Contact not found\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()

        self.directory.root = self.directory.delete(self.directory.root, name)

        self.output.insert(tk.END, f"Deleted (if existed): {name}\n")
        self.clear_inputs()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output.delete(1.0, tk.END)

        contacts = self.directory.inorder(self.directory.root)

        if not contacts:
            self.output.insert(tk.END, "No contacts\n")
            return

        for name, phone in contacts:
            self.output.insert(tk.END, f"{name} : {phone}\n")

    def clear_inputs(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    # ---------------- TREE VISUALISATION ----------------

    def draw_tree(self):
        self.canvas.delete("all")

        if not self.directory.root:
            return

        self._draw(self.directory.root, 400, 30, 200)

    def _draw(self, node, x, y, offset):
        if not node:
            return

        radius = 20

        if node.left:
            self.canvas.create_line(x, y, x - offset, y + 70)
            self._draw(node.left, x - offset, y + 70, offset // 2)

        if node.right:
            self.canvas.create_line(x, y, x + offset, y + 70)
            self._draw(node.right, x + offset, y + 70, offset // 2)

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill="lightblue")
        self.canvas.create_text(x, y, text=node.name[:8])

    # ---------------- BENCHMARK ----------------

    def benchmark(self):
        self.directory.root = None

        N = 1000

        names = [''.join(random.choices(string.ascii_lowercase, k=6)) for _ in range(N)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(N)]

        start = time.time()
        for i in range(N):
            self.directory.root = self.directory.insert(self.directory.root, names[i], phones[i])
        insert_time = time.time() - start

        search_samples = random.sample(names, 500)

        start = time.time()
        found = 0
        for name in search_samples:
            if self.directory.search(self.directory.root, name):
                found += 1
        search_time = time.time() - start

        delete_samples = random.sample(names, 100)

        start = time.time()
        for name in delete_samples:
            self.directory.root = self.directory.delete(self.directory.root, name)
        delete_time = time.time() - start

        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END,
            f"BENCHMARK RESULTS\n"
            f"Insert: {insert_time:.4f}s\n"
            f"Search: {search_time:.4f}s (found {found})\n"
            f"Delete: {delete_time:.4f}s\n"
        )

        self.draw_tree()


# ---------------- RUN APP ----------------

if __name__ == "__main__":
    root = tk.Tk()
    app = BSTVisualizerApp(root)
    root.mainloop()