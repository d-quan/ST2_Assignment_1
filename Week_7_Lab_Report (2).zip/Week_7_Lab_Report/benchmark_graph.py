import time
import random
import string
import matplotlib.pyplot as plt
from bst import BST
from avl import AVLTree

# Re-use BST and AVL classes from previous code 
# Use BST and AVLTree classes already defined with 
# insert/search/delete methods.

def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        # --- BST ---
        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        # --- AVL ---
        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

        # --- RED BLACK TREE ---
        class RBTNode:
            def __init__(self, name, phone):
                self.name = name
                self.phone = phone
                self.color = "red"
                self.left = None
                self.right = None
                self.parent = None

        class RedBlackTree:
            def __init__(self):
                self.root = None

            def insert(self, node, name, phone):
                if not node:
                    new_node = RBTNode(name, phone)
                    new_node.color = "black"
                    return new_node

                if name < node.name:
                    node.left = self.insert(node.left, name, phone)
                elif name > node.name:
                    node.right = self.insert(node.right, name, phone)
                else:
                    node.phone = phone

                return node

            def search(self, node, name):
                if not node or node.name == name:
                    return node
                if name < node.name:
                    return self.search(node.left, name)
                return self.search(node.right, name)

            def delete(self, node, name):
                if not node:
                    return node

                if name < node.name:
                    node.left = self.delete(node.left, name)
                elif name > node.name:
                    node.right = self.delete(node.right, name)
                else:
                    if not node.left:
                        return node.right
                    if not node.right:
                        return node.left

                    temp = node.right
                    while temp.left:
                        temp = temp.left

                    node.name = temp.name
                    node.phone = temp.phone
                    node.right = self.delete(node.right, temp.name)

                return node

        rbt = RedBlackTree()
        start = time.time()
        for i in range(n):
            rbt.root = rbt.insert(rbt.root, names[i], phones[i])
        rbt_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            rbt.search(rbt.root, name)
        rbt_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            rbt.root = rbt.delete(rbt.root, name)
        rbt_times['delete'].append(time.time() - start)

    # Plot results
    plt.figure(figsize=(12, 8))

    # Insertions plot
    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert')
    plt.plot(sizes, rbt_times['insert'], label='RBT Insert')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()

    # Searches plot
    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search')
    plt.plot(sizes, avl_times['search'], label='AVL Search')
    plt.plot(sizes, rbt_times['search'], label='RBT Search')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()

    # Deletions plot
    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete')
    plt.plot(sizes, rbt_times['delete'], label='RBT Delete')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    sizes_to_test = [1000, 2000, 4000, 8000, 10000]
    run_benchmark_for_sizes(sizes_to_test)