count = 0  #(global variable)

def main():
    global count
    n = int(input("Enter number of disks: "))

    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')

    print("Number of moves is", count)


def moveDisks(n, fromTower, toTower, auxTower):
    global count

    if n == 1:
        count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)

main()