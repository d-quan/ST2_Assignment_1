import timeit

#Sum

def sum_recursive(n):
    if n == 1:
        return 1
    return n + sum_recursive(n-1)

def sum_iterative(n):
    total = 0
    for i in range(1, n+1):
        total += i
    return total


#Fibonacci

def fibonacci_recursive(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci_recursive(n-1) + fibonacci_recursive(n-2)


def fibonacci_iterative(n):

    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a = 0
    b = 1

    for i in range(2, n+1):
        c = a + b
        a = b
        b = c

    return b


#Factorial

def factorial_recursive(n):
    if n == 0:
        return 1
    return n * factorial_recursive(n-1)


def factorial_iterative(n):

    result = 1
    for i in range(1, n+1):
        result *= i

    return result


#Test

n = 5

print("SUM TEST")
print("Recursive:", timeit.timeit(lambda: sum_recursive(n), number=1000))
print("Iterative:", timeit.timeit(lambda: sum_iterative(n), number=1000))

print()

print("FACTORIAL TEST")
print("Recursive:", timeit.timeit(lambda: factorial_recursive(n), number=1000))
print("Iterative:", timeit.timeit(lambda: factorial_iterative(n), number=1000))

print()

print("FIBONACCI TEST")
print("Recursive:", timeit.timeit(lambda: fibonacci_recursive(n), number=1000))
print("Iterative:", timeit.timeit(lambda: fibonacci_iterative(n), number=1000))