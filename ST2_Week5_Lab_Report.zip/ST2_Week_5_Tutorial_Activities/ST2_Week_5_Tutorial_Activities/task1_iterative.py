def sum_iterative(n):
    total = 0
    for i in range(1, n+1):
        total += i
    return total

def fibonacci_iterative(n):

    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a = 0
    b = 1

    for i in range(2, n+1):
        c = a + b
        a = b
        b = c

    return b

def factorial_iterative(n):

    result = 1

    for i in range(1, n+1):
        result *= i

    return result