import random
import timeit


def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2]
        right_split = array[len(array)//2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)

        return merge(left, right)


def merge(left, right):
    merged = []

    left_pointer = 0
    right_pointer = 0

    while left_pointer < len(left) and right_pointer < len(right):

        if left[left_pointer] < right[right_pointer]:
            merged.append(left[left_pointer])
            left_pointer += 1
        else:
            merged.append(right[right_pointer])
            right_pointer += 1

    merged.extend(left[left_pointer:])
    merged.extend(right[right_pointer:])

    return merged

def insertion_sort(arr):

    for i in range(1, len(arr)):

        current_element = arr[i]
        j = i - 1

        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = current_element

    return arr

sizes = [100, 1000, 5000, 10000]

for size in sizes:

    large_random_list = [random.randint(1, 1000) for _ in range(size)]

    insertion_time = timeit.timeit(lambda: insertion_sort(large_random_list[:]), number=10)
    merge_time = timeit.timeit(lambda: merge_sort(large_random_list[:]), number=10)

    print("List size:", size)
    print(f"Insertion Sort took: {insertion_time:.6f} seconds")
    print(f"Merge Sort took: {merge_time:.6f} seconds")
    print()