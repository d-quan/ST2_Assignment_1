from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.size = 300
        self.canvas = Canvas(window, width=self.size, height=self.size)
        self.canvas.pack()

        frame = Frame(window)
        frame.pack()

        Label(frame, text="Enter an order: ").pack(side=LEFT)

        self.order = StringVar()

        Entry(frame, textvariable=self.order).pack(side=LEFT)

        Button(frame,
               text="Display",
               command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        # Equilateral triangle starting points
        p1 = (150, 20)
        p2 = (20, 260)
        p3 = (280, 260)

        n = int(self.order.get())

        self.koch_curve(n, p1, p2)
        self.koch_curve(n, p2, p3)
        self.koch_curve(n, p3, p1)

    def koch_curve(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1],
                                    p2[0], p2[1],
                                    tags="line")
        else:
            x1, y1 = p1
            x2, y2 = p2

            dx = (x2 - x1) / 3
            dy = (y2 - y1) / 3

            a = (x1 + dx, y1 + dy)
            b = (x1 + 2 * dx, y1 + 2 * dy)

            # peak point (rotation 60 degrees)
            angle = math.radians(60)

            px = a[0] + math.cos(angle) * dx - math.sin(angle) * dy
            py = a[1] + math.sin(angle) * dx + math.cos(angle) * dy
            peak = (px, py)

            self.koch_curve(order - 1, p1, a)
            self.koch_curve(order - 1, a, peak)
            self.koch_curve(order - 1, peak, b)
            self.koch_curve(order - 1, b, p2)


KochSnowflake()