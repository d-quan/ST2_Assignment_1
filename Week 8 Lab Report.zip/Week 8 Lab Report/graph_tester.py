# graph_tester.py
from graph import Graph

print("UNDIRECTED GRAPH")

g = Graph()
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.print_graph()
print()

g.add_edge('A', 'B')
g.print_graph()
print()

g.add_edge('B', 'C')
g.print_graph()
print()

g.add_edge('C', 'D')
g.print_graph()
print()

g.remove_edge('A', 'B')
g.print_graph()
print()

g.remove_vertex('D')
g.print_graph()
print()

print("DIRECTED GRAPH")

g = Graph(directed=True)
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.print_graph()
print()

g.add_edge('A', 'B')
g.print_graph()
print()

g.add_edge('B', 'C')
g.print_graph()
print()

g.add_edge('C', 'D')
g.print_graph()
print()

g.remove_edge('A', 'B')
g.print_graph()
print()

g.remove_vertex('D')
g.print_graph()
print()

print("\n========================")
print("TASK 2 BFS TEST")
print("========================")

bfs_graph = Graph()

for v in ['A', 'B', 'C', 'D']:
    bfs_graph.add_vertex(v)

bfs_graph.add_edge('A', 'B')
bfs_graph.add_edge('A', 'C')
bfs_graph.add_edge('B', 'D')
bfs_graph.add_edge('C', 'D')

print("BFS starting from vertex 'A':")
visited_bfs = bfs_graph.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

print("\n========================")
print("TASK 3 DFS TEST")
print("========================")

print("DFS starting from vertex 'A':")
visited_dfs = bfs_graph.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

print("\n========================")
print("TASK 4 CYCLE DETECTION TEST")
print("========================")

cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)

cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')

print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)

acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())

print("\n========================")
print("TASK 5 WEIGHTED DIRECTED GRAPH")
print("========================")

wg = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()